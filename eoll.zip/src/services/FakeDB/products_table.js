const products = [
    {
        id:1,
        name:"MAGNUS",
        category:"ladies",
        material:"glass",
        size:"medium",
        shape:"round",
        color:"red",
        brands:"bvlgari",
        price: 100,
        imgUrl:"./assets/images/products/3025.jpg"
    },
    {
        id:2,
        name:"MUSE",
        category:"ladies",
        material:"glass",
        size:"medium",
        shape:"round",
        color:"red",
        brands:"bvlgari",
        price: 100,
        imgUrl:"./assets/images/products/aviator.jpg"
    },
    {
        id:4,
        name:"3025",
        category:"ladies",
        material:"glass",
        size:"medium",
        shape:"round",
        color:"red",
        brands:"bvlgari",
        price: 100,
        imgUrl:"./assets/images/products/hsp.jpg"
    },
    {
        id:5,
        name:"POOLSIDE",
        category:"ladies",
        material:"glass",
        size:"medium",
        shape:"round",
        color:"red",
        brands:"bvlgari",
        price: 100,
        imgUrl:"./assets/images/products/magnus.jpg"
    },
    {
        id:6,
        name:"MAGNUS",
        category:"ladies",
        material:"glass",
        size:"medium",
        shape:"round",
        color:"red",
        brands:"bvlgari",
        price: 100,
        imgUrl:"./assets/images/products/muse.jpg"
    },
    {
        id:7,
        name:"MAGNUS",
        category:"ladies",
        material:"glass",
        size:"narrow",
        shape:"round",
        color:"red",
        brands:"bvlgari",
        price: 100,
        imgUrl:"./assets/images/products/poolside.jpg"
    },
    {
        id:8,
        name:"MAGNUS",
        category:"ladies",
        material:"glass",
        size:"medium",
        shape:"round",
        color:"red",
        brands:"bvlgari",
        price: 100,
        imgUrl:"./assets/images/products/aviator.jpg"
    },
    {
        id:9,
        name:"MAGNUS",
        category:"ladies",
        material:"glass",
        size:"narrow",
        shape:"round",
        color:"red",
        brands:"bvlgari",
        price: 100,
        imgUrl:"./assets/images/products/3025.jpg"
    },
    {
        id:10,
        name:"MAGNUS",
        category:"ladies",
        material:"glass",
        size:"medium",
        shape:"round",
        color:"red",
        brands:"bvlgari",
        price: 100,
        imgUrl:"./assets/images/products/hsp.jpg"
    },
    {
        id:11,
        name:"MAGNUS",
        category:"ladies",
        material:"glass",
        size:"wide",
        shape:"round",
        color:"red",
        brands:"bvlgari",
        price: 100,
        imgUrl:"./assets/images/products/3025.jpg"

    },
];
export default products;